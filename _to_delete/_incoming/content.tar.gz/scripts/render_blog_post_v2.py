#!/usr/bin/env python3
"""
Render a structured blog-post JSON into a full HTML file matching the REAL,
CURRENT opalradiant.com blog template (verified directly against the live
repo on 2026-07-15 — header/footer/analytics baked in, extensionless URLs,
self-hosted font preloads). This supersedes render_blog_post.py, which was
built against a stale/forked copy of the site.

Usage:
    python3 scripts/render_blog_post_v2.py <content.json> --out <out.html>
"""
import argparse
import html
import json
import os

def esc(s):
    return html.escape(s, quote=True)


ANALYTICS_HEAD = '''  <!-- Microsoft Clarity: deferred until after the page is usable -->
  <script>
    window.addEventListener('load', function () {
      setTimeout(function () {
        (function(c,l,a,r,i,t,y){
          c[a]=c[a]||function(){(c[a].q=c[a].q||[]).push(arguments)};
          t=l.createElement(r);t.async=1;t.src="https://www.clarity.ms/tag/"+i;
          y=l.getElementsByTagName(r)[0];y.parentNode.insertBefore(t,y);
        })(window, document, "clarity", "script", "uk6elnx25m");
      }, 1500);
    }, { once: true });
  </script>

  <!-- Google tag (gtag.js) — GA4 + Google Ads -->
  <script>
    window.addEventListener('load', function () {
      setTimeout(function () {
        var tag = document.createElement('script');
        tag.async = true;
        tag.src = 'https://www.googletagmanager.com/gtag/js?id=G-S2T33WR4TY';
        document.head.appendChild(tag);
      }, 1500);
    }, { once: true });
  </script>
  <script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());
    gtag('config', 'G-S2T33WR4TY');
    gtag('config', 'AW-18204959421', {'allow_enhanced_conversions': true});
  </script>'''

HEADER_HTML = '''  <header class="header" role="banner">
    <div class="header__inner">
      <a href="/" class="header__logo" aria-label="Opal Radiant — Home">
        <img src="/images/opal-logo.webp" alt="OPAL Radiant Studio logo" width="140" height="45">
      </a>

      <button class="nav__toggle" aria-label="Toggle navigation" aria-expanded="false">
        <span></span><span></span><span></span>
      </button>

      <nav class="nav" role="navigation" aria-label="Main navigation">
        <ul class="nav__list">
          <li class="nav__item">
            <a href="/" class="nav__link">Home</a>
          </li>
          <li class="nav__item nav__item--has-dropdown nav__item--mega">
            <a href="/services/" class="nav__link">Treatments</a>
            <div class="nav__dropdown nav__mega">
              <div class="nav__mega-col">
                <span class="nav__mega-heading">Hair</span>
                <a href="/services/laser-hair-removal-mumbai">Laser Hair Removal</a>
                <a href="/services/hair-prp">Hair PRP</a>
                <a href="/services/hair-fillers">Hair Fillers</a>
              </div>
              <div class="nav__mega-col">
                <span class="nav__mega-heading">Skin Treatments</span>
                <a href="/services/carbon-laser-facial">Carbon Laser Facial</a>
                <a href="/services/hydra-facial">Hydra Facial</a>
                <a href="/services/chemical-peel">Chemical Peel</a>
                <a href="/services/mnrf">MNRF</a>
                <a href="/services/hifu-face-lift">HIFU Face Lift</a>
                <a href="/services/tattoo-removal">Tattoo Removal</a>
              </div>
              <div class="nav__mega-col">
                <span class="nav__mega-heading">Face &amp; Body</span>
                <a href="/services/fat-freeze">Fat Freeze / Cryolipolysis</a>
                <a href="/services/hifem-body-toning">HIFEM Body Toning</a>
                <a href="/services/jordi-shape">Jordi Shape</a>
              </div>
            </div>
          </li>
          <li class="nav__item nav__item--has-dropdown">
            <a href="/locations/powai" class="nav__link">Locations</a>
            <div class="nav__dropdown">
              <a href="/locations/powai">Powai</a>
              <a href="/locations/wadala">Wadala</a>
              <a href="/locations/borivali">Borivali</a>
              <a href="/locations/thane">Thane</a>
            </div>
          </li>
          <li class="nav__item">
            <a href="/pricing" class="nav__link">Pricing</a>
          </li>
          <li class="nav__item">
            <a href="/about" class="nav__link">About</a>
          </li>
          <li class="nav__item">
            <a href="/blog/" class="nav__link nav__link--active">Blog</a>
          </li>
          <li class="nav__item">
            <a href="/contact" class="nav__link">Contact</a>
          </li>
        </ul>
      </nav>

      <div class="header__cta">
        <a href="/book-appointment" class="btn btn--primary btn--sm">Book Free Appointment</a>
      </div>
    </div>
    <div class="nav__overlay"></div>
  </header>'''

FOOTER_HTML = '''  <footer class="footer" role="contentinfo">
    <div class="container">
      <div class="footer__grid">

        <!-- Brand -->
        <div class="footer__brand">
          <img src="/images/opal-logo.webp" alt="OPAL Radiant" width="130" height="42" loading="lazy">
          <p class="footer__brand-text">OPAL Radiant is a women-only aesthetic clinic in Mumbai &amp; Thane, led by Dr. Punit Sakhare (MD Dermatologist). We offer laser hair removal, fat freeze, skin treatments and face lift procedures using clinically-tested aesthetic technology in a private, luxurious setting.</p>
          <div class="footer__social">
            <a href="https://www.facebook.com/opalradiant" target="_blank" rel="noopener" aria-label="Opal Radiant on Facebook">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>
            </a>
            <a href="https://www.instagram.com/opalradiant" target="_blank" rel="noopener" aria-label="Opal Radiant on Instagram">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z"/></svg>
            </a>
          </div>
        </div>

        <!-- Treatments -->
        <div>
          <h4 class="footer__heading">Treatments</h4>
          <ul class="footer__links">
            <li><a href="/services/laser-hair-removal-mumbai">Laser Hair Removal</a></li>
            <li><a href="/services/fat-freeze">Fat Freeze</a></li>
            <li><a href="/services/carbon-laser-facial">Carbon Laser Facial</a></li>
            <li><a href="/services/hifu-face-lift">HIFU Face Lift</a></li>
            <li><a href="/services/tattoo-removal">Tattoo Removal</a></li>
            <li><a href="/services/chemical-peel">Chemical Peel</a></li>
            <li><a href="/services/hydra-facial">Hydra Facial</a></li>
            <li><a href="/services/mnrf">MNRF</a></li>
            <li><a href="/services/hair-prp">Hair PRP</a></li>
            <li><a href="/services/hair-fillers">Hair Fillers</a></li>
            <li><a href="/services/hifem-body-toning">HIFEM Body Toning</a></li>
            <li><a href="/services/jordi-shape">Jordi Shape</a></li>
          </ul>
        </div>

        <!-- Company -->
        <div>
          <h4 class="footer__heading">Company</h4>
          <ul class="footer__links">
            <li><a href="/about">About Us</a></li>
            <li><a href="/about#doctor">Our Dermatologist</a></li>
            <li><a href="/blog/">Blog</a></li>
            <li><a href="/care/">Pre &amp; Post Care</a></li>
            <li><a href="/faq">FAQ</a></li>
            <li><a href="/pricing">Pricing</a></li>
            <li><a href="/privacy-policy">Privacy Policy</a></li>
            <li><a href="/terms">Terms of Service</a></li>
          </ul>
        </div>

        <!-- Central Contact -->
        <div>
          <h4 class="footer__heading">Get in Touch</h4>
          <div class="footer__contact-item">
            <span><svg class="icon" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6A19.79 19.79 0 0 1 2.12 4.18 2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z"/></svg></span>
            <a href="tel:+917703037070">+91 77030 37070</a>
          </div>
          <div class="footer__contact-item">
            <span><svg class="icon" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg></span>
            <a href="mailto:info@opalradiant.com">info@opalradiant.com</a>
          </div>
          <div class="footer__contact-item">
            <span><svg class="icon" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg></span>
            <a href="https://wa.me/917703037070" target="_blank" rel="noopener">WhatsApp Us</a>
          </div>
          <div class="footer__contact-item">
            <span><svg class="icon" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"/><polyline points="12,6 12,12 16,14"/></svg></span>
            <span>Tue&ndash;Sun, 11 AM &ndash; 8 PM</span>
          </div>
          <a href="/book-appointment" class="btn btn--primary btn--block" style="margin-top:1rem;">Book Free Appointment</a>
        </div>

      </div>

      <!-- All Four Clinic Addresses -->
      <div class="footer__branches">
        <div class="footer__branches-head">
          <span class="footer__branches-eyebrow">Visit Us</span>
          <h4 class="footer__branches-heading">Our Clinics Across Mumbai &amp; Thane</h4>
          <p class="footer__branches-lead">Four women-only studios &mdash; each led by a senior clinician trained by Dr. Punit Sakhare, all following the same clinical protocols.</p>
        </div>
        <div class="footer__branches-grid">
          <article class="footer__branch">
            <div class="footer__branch-pin" aria-hidden="true">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
            </div>
            <span class="footer__branch-eyebrow">Opal Radiant</span>
            <h5 class="footer__branch-name"><a href="/locations/powai">Powai</a></h5>
            <address class="footer__branch-addr">B1-203, 2nd Floor, Boomerang, Chandivali, Powai, Mumbai 400072</address>
            <div class="footer__branch-actions">
              <a href="tel:+917703037070" class="footer__branch-btn" aria-label="Call Powai clinic">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6A19.79 19.79 0 0 1 2.12 4.18 2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.96.36 1.9.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.91.34 1.85.57 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
                <span>Call</span>
              </a>
              <a href="https://maps.app.goo.gl/kgs/npEy38" target="_blank" rel="noopener" class="footer__branch-btn" aria-label="Directions to Powai clinic">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polygon points="3 11 22 2 13 21 11 13 3 11"/></svg>
                <span>Directions</span>
              </a>
            </div>
          </article>

          <article class="footer__branch">
            <div class="footer__branch-pin" aria-hidden="true">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
            </div>
            <span class="footer__branch-eyebrow">Opal Radiant</span>
            <h5 class="footer__branch-name"><a href="/locations/wadala">Wadala</a></h5>
            <address class="footer__branch-addr">Unit 212, Lodha Supremus, New Cuff Parade Wadala, Sion, Mumbai 400037</address>
            <div class="footer__branch-actions">
              <a href="tel:+917745005500" class="footer__branch-btn" aria-label="Call Wadala clinic">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6A19.79 19.79 0 0 1 2.12 4.18 2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.96.36 1.9.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.91.34 1.85.57 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
                <span>Call</span>
              </a>
              <a href="https://share.google/26EklOSmhufF9Ixp7" target="_blank" rel="noopener" class="footer__branch-btn" aria-label="Directions to Wadala clinic">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polygon points="3 11 22 2 13 21 11 13 3 11"/></svg>
                <span>Directions</span>
              </a>
            </div>
          </article>

          <article class="footer__branch">
            <div class="footer__branch-pin" aria-hidden="true">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
            </div>
            <span class="footer__branch-eyebrow">Opal Radiant</span>
            <h5 class="footer__branch-name"><a href="/locations/borivali">Borivali</a></h5>
            <address class="footer__branch-addr">Friends Business Bay, 1301, Lokmanya Tilak Rd, Borivali West, Mumbai 400092</address>
            <div class="footer__branch-actions">
              <a href="tel:+919800498002" class="footer__branch-btn" aria-label="Call Borivali clinic">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6A19.79 19.79 0 0 1 2.12 4.18 2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.96.36 1.9.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.91.34 1.85.57 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
                <span>Call</span>
              </a>
              <a href="https://share.google/0CcZQfsY6swbK2dzQ" target="_blank" rel="noopener" class="footer__branch-btn" aria-label="Directions to Borivali clinic">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polygon points="3 11 22 2 13 21 11 13 3 11"/></svg>
                <span>Directions</span>
              </a>
            </div>
          </article>

          <article class="footer__branch">
            <div class="footer__branch-pin" aria-hidden="true">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
            </div>
            <span class="footer__branch-eyebrow">Opal Radiant</span>
            <h5 class="footer__branch-name"><a href="/locations/thane">Thane</a></h5>
            <address class="footer__branch-addr">16th Floor, 1618, Hiranandani Solus, Hiranandani Estate, Thane West 400607</address>
            <div class="footer__branch-actions">
              <a href="tel:+918604410418" class="footer__branch-btn" aria-label="Call Thane clinic">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6A19.79 19.79 0 0 1 2.12 4.18 2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.96.36 1.9.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.91.34 1.85.57 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
                <span>Call</span>
              </a>
              <a href="https://share.google/zKrCeLAH18LdgGWRe" target="_blank" rel="noopener" class="footer__branch-btn" aria-label="Directions to Thane clinic">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polygon points="3 11 22 2 13 21 11 13 3 11"/></svg>
                <span>Directions</span>
              </a>
            </div>
          </article>
        </div>
      </div>

      <div class="footer__bottom">
        <p>&copy; 2026 Opal Radiant Studio. All rights reserved. &middot; Results vary by individual. Consultation required to confirm suitability.</p>
        <p>
          <a href="/privacy-policy">Privacy Policy</a>
          <span style="margin:0 0.5rem;">|</span>
          <a href="/terms">Terms of Service</a>
          <span style="margin:0 0.5rem;">|</span>
          <a href="/sitemap.xml">Sitemap</a>
        </p>
      </div>
    </div>
  </footer>

  <a href="https://wa.me/917703037070?text=Hi%2C%20I%20want%20to%20book%20a%20free%20consultation" class="whatsapp-float" target="_blank" rel="noopener" aria-label="Chat on WhatsApp"><svg width="28" height="28" viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg></a>'''


def render_quick_facts(slug, title, facts):
    rows = '\n'.join(
        f'''            <div class="quick-facts__row">
              <dt class="quick-facts__label">{esc(f["label"])}</dt>
              <dd class="quick-facts__value">{f["value"]}</dd>
            </div>''' for f in facts
    )
    return f'''        <section class="quick-facts" aria-label="Quick facts — {esc(title)}">
          <div class="quick-facts__card">
            <h2 class="quick-facts__title">Quick Facts</h2>
            <dl class="quick-facts__list" id="{slug}-quick-facts">
{rows}
            </dl>
          </div>
        </section>'''


def render_sources(sources):
    if not sources:
        return ''
    items = '\n'.join(
        f'            <li id="src-{i+1}">{s["text"]}'
        + (f' — <a href="{esc(s["url"])}" target="_blank" rel="noopener noreferrer">source</a>' if s.get('url') else '')
        + '</li>'
        for i, s in enumerate(sources)
    )
    return f'''
        <section class="blog-post__sources" style="margin-top:2.5rem; padding-top:1.5rem; border-top:1px solid var(--color-border, #D4CBC0);">
          <h2 style="font-size:1.2rem;">Sources &amp; Further Reading</h2>
          <ol style="font-size:0.92rem; color:var(--color-text-light,#574C3F); line-height:1.8; padding-left:1.25rem;">
{items}
          </ol>
          <p style="font-size:0.85rem; color:var(--color-text-light,#574C3F); margin-top:0.75rem;">This article is for general education and does not replace an in-person dermatologist consultation. Individual results and suitability vary — book a free consultation to discuss your case.</p>
        </section>'''


def render_faq_schema(faqs):
    entities = [
        {
            "@type": "Question",
            "name": f["q"],
            "acceptedAnswer": {"@type": "Answer", "text": f["a"]},
        }
        for f in faqs
    ]
    return json.dumps({
        "@context": "https://schema.org",
        "@type": "FAQPage",
        "mainEntity": entities,
    }, indent=4)


def render_faq_html(faqs):
    items = '\n'.join(f'''            <div class="faq__item">
              <button class="faq__question" aria-expanded="false">{esc(f["q"])}</button>
              <div class="faq__answer"><p>{f["a"]}</p></div>
            </div>''' for f in faqs)
    return f'''        <section style="margin-top:3rem;">
          <h2>Frequently Asked Questions</h2>
          <div class="faq">
{items}
          </div>
        </section>'''


def render_link_group(heading, links):
    if not links:
        return ''
    btns = ''.join(
        f'<a href="{esc(l["url"])}" class="btn btn--outline btn--sm" style="margin:0.25rem;">{esc(l["label"])}</a>'
        for l in links
    )
    return f'''
        <div style="background:#F6F3EC; padding:2rem; border-radius:12px; margin-top:3rem;">
          <h3 style="font-family:'Oswald',sans-serif; margin-bottom:1rem;">{esc(heading)}</h3>
          <div style="display:flex; flex-wrap:wrap; gap:0.5rem; margin-bottom:1.5rem;">{btns}
          </div>
          <a href="/book-appointment" class="btn btn--primary">Book Free Consultation</a>
        </div>'''


def render_see_also(links):
    if not links:
        return ''
    rendered = []
    for l in links:
        if l.get('pending_slug'):
            rendered.append(
                f'          <li data-pending-link="{esc(l["pending_slug"])}">{esc(l["label"])}</li>'
            )
        else:
            rendered.append(f'          <li><a href="{esc(l["url"])}">{esc(l["label"])}</a></li>')
    items = '\n'.join(rendered)
    items += '\n          <li><a href="/book-appointment">Book a Free Consultation</a></li>'
    return f'''
    <!-- OPAL_BLOG_SEEALSO_V1 -->
    <aside class="section section--alt blog-seealso">
      <div class="container" style="max-width:820px;">
        <h2 style="font-size:1.35rem; margin-top:0;">See also</h2>
        <ul style="margin: 0; padding: 0; list-style: none; line-height: 2;">
{items}
        </ul>
      </div>
    </aside>
    <!-- /OPAL_BLOG_SEEALSO_V1 -->'''


def render(post):
    slug = post['slug']
    title = post['title']
    meta_description = post['meta_description']
    category = post['category']
    publish_date = post['publish_date']
    read_time = post.get('read_time', '7 min read')

    body_sections = ''.join(
        f'\n<h2>{esc(s["heading"])}</h2>\n{s["html"]}\n' for s in post['sections']
    )

    quick_facts_html = render_quick_facts(slug, title, post['quick_facts'])
    sources_html = render_sources(post.get('sources', []))
    faq_html = render_faq_html(post['faqs'])
    faq_schema = render_faq_schema(post['faqs'])
    related_html = render_link_group('Related Services at OPAL Radiant', post.get('related_services', []))
    see_also_html = render_see_also(post.get('see_also', []))

    blogposting_schema = json.dumps({
        "@context": "https://schema.org",
        "@type": "BlogPosting",
        "headline": title,
        "description": meta_description,
        "author": {"@type": "Person", "name": "Dr. Punit Sakhare", "jobTitle": "MD Dermatologist"},
        "publisher": {
            "@type": "Organization", "name": "OPAL Radiant Studio", "url": "https://opalradiant.com",
            "logo": {"@type": "ImageObject", "url": "https://opalradiant.com/images/opal-logo.webp"},
        },
        "datePublished": publish_date,
        "dateModified": publish_date,
        "mainEntityOfPage": f"https://opalradiant.com/blog/{slug}",
        "image": f"https://opalradiant.com/images/blog/{slug}.jpg",
    }, indent=4)

    speakable_schema = json.dumps({
        "@context": "https://schema.org",
        "@type": "WebPage",
        "speakable": {
            "@type": "SpeakableSpecification",
            "cssSelector": [f"#{slug}-quick-facts", ".quick-facts__title", "h1"],
        },
        "url": f"https://opalradiant.com/blog/{slug}",
    }, indent=4)

    html_out = f'''<!DOCTYPE html>
<html lang="en-IN">
<head>
{ANALYTICS_HEAD}

  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>{esc(title)} | OPAL Radiant Blog</title>
  <meta name="description" content="{esc(meta_description)}">
  <link rel="canonical" href="https://opalradiant.com/blog/{slug}">
  <meta property="og:title" content="{esc(title)}">
  <meta property="og:description" content="{esc(meta_description)}">
  <meta property="og:type" content="article">
  <meta property="og:url" content="https://opalradiant.com/blog/{slug}">
  <meta property="og:image" content="https://opalradiant.com/images/blog/{slug}.jpg">
  <meta property="og:locale" content="en_IN">
  <meta property="og:site_name" content="OPAL Radiant Studio">
  <meta name="twitter:card" content="summary_large_image">
  <meta name="twitter:title" content="{esc(title)}">
  <meta name="twitter:description" content="{esc(meta_description)}">
  <meta name="twitter:image" content="https://opalradiant.com/images/blog/{slug}.jpg">
  <meta name="robots" content="index, follow">
  <link rel="icon" href="/images/favicon.ico" type="image/x-icon">
  <link rel="apple-touch-icon" href="/images/apple-touch-icon.png">
  <link rel="preload" href="/fonts/arimo-latin.woff2" as="font" type="font/woff2" crossorigin>
  <link rel="preload" href="/fonts/oswald-latin.woff2" as="font" type="font/woff2" crossorigin>
  <link rel="stylesheet" href="/css/style.css">
  <script type="application/ld+json">
  {blogposting_schema}
  </script>
  <script type="application/ld+json">
  {faq_schema}
  </script>
  <script type="application/ld+json">
  {speakable_schema}
  </script>
</head>
<body>

{HEADER_HTML}

  <main>
    <article class="blog-post">
      <div class="container" style="max-width:800px;">
        <nav class="breadcrumb" aria-label="Breadcrumb">
          <ol class="breadcrumb__list">
            <li class="breadcrumb__item"><a href="/">Home</a></li>
            <li class="breadcrumb__item"><a href="/blog/">Blog</a></li>
            <li class="breadcrumb__item breadcrumb__item--active" aria-current="page">{esc(category)}</li>
          </ol>
        </nav>

        <header class="blog-post__header">
          <span class="blog-card__category">{esc(category)}</span>
          <h1>{esc(title)}</h1>
          <p class="blog-post__meta">By Dr. Punit Sakhare, MD Dermatologist &middot; {publish_date} &middot; {esc(read_time)}</p>
        </header>

        <figure class="blog-post__hero">
          <picture>
            <source srcset="/images/blog/{slug}.webp" type="image/webp">
            <img src="/images/blog/{slug}.jpg" alt="{esc(post['image_alt'])}"
                 width="1200" height="800" loading="eager" decoding="async"
                 fetchpriority="high">
          </picture>
        </figure>

{quick_facts_html}

        <div class="blog-post__content">
{post['intro']}
{body_sections}
        </div>
{sources_html}
{related_html}

{faq_html}

      </div>
    </article>
{see_also_html}
  </main>

{FOOTER_HTML}

  <script src="/js/main.js" defer></script>

</body>
</html>
'''
    return html_out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('content_json')
    ap.add_argument('--out')
    args = ap.parse_args()

    with open(args.content_json) as f:
        post = json.load(f)

    out_html = render(post)

    out_path = args.out or os.path.splitext(args.content_json)[0] + '.html'
    with open(out_path, 'w') as f:
        f.write(out_html)
    print(f'Rendered {out_path} ({len(out_html)} bytes)')


if __name__ == '__main__':
    main()
